package iss.java.mail;

import java.io.IOException;
import java.util.Properties;

import javax.mail.Address;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeUtility;

public class Main2014302580082 implements IMailService{
	Session sendMailSession;
	Store store;
	Folder folder;
	Properties props= new Properties();
	private String smtp = "smtp.163.com";
	private String imap = "imap.163.com";
	private String username = "18140514016@163.com";
	private String password = "jaxtdmqymgyfkryu";
	private MailAuthenticator authenticator = new MailAuthenticator(username,password);
		
	public void connect() throws MessagingException{
	
		//��ʼ��������
		
		props.put("mail.smtp.host",smtp);
		props.put("mail.smtp.auth","true");
		props.put("mail.imap.host",imap);
		props.put("mail.store.protocol","imap");
		//��ȡ����Ự����
		sendMailSession = Session.getInstance(props,authenticator);
		System.out.println("ok!");
							
	}

	@Override
	
	public void send(String recipient, String subject, Object content) throws MessagingException {
		// TODO Auto-generated method stub
		try{
	    MailAuthenticator authenticator = new MailAuthenticator(username,password);
	    sendMailSession = Session.getInstance(props,authenticator);
		//����session����һ���ʼ���Ϣ
		Message message = new MimeMessage(sendMailSession);
		//�����ʼ���Ϣ�ķ�����
		message.setFrom(new InternetAddress(username)); 
	    //�����ռ��˵�ַ����Ϣ��
		if(recipient!=null){
		 message.addRecipient(Message.RecipientType.TO, new InternetAddress(recipient));
		}
	   //�����ʼ���Ϣ���������Ҫ����
		 message.setSubject(subject);
		 message.setContent(content.toString(), "text/html;charset=utf-8");
		 //�����ʼ�
		 message.saveChanges();
		 System.out.println("���ڷ����ʼ�...");
		 Transport transport = sendMailSession.getTransport("smtp");
		 transport.connect();
		 //transport.connect(smtp,username,password);
		 transport.sendMessage(message, message.getAllRecipients());
		 System.out.println("�ʼ����ͳɹ���");
		 transport.close();
		}catch(MessagingException e){
			e.printStackTrace();
			System.out.println("�ʼ�����ʧ�ܣ�");
		}
	}
	
	
	@Override
	public boolean listen() throws MessagingException {
		// TODO Auto-generated method stub	
		try{
		     store = sendMailSession.getStore();
		     store.connect();
		     //��������е�Folder����
		     folder = store.getFolder("inbox");
		     //�ԡ�ֻ������
		     folder.open(Folder.READ_ONLY);
		     int count = folder.getMessageCount();
		     System.out.println("һ���յ���"+count+"���ʼ�");
		     folder.close(true);
		     store.close(); 
		     if(count!=0) return true;
		     else return false;
		}catch(MessagingException e){
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public String getReplyMessageContent(String sender, String subject) throws MessagingException, IOException {
		// TODO Auto-generated method stub
		 store.connect();
		 folder = store.getFolder("inbox");
		 folder.open(Folder.READ_ONLY);
		 Message[] message = folder.getMessages();
	     int c = message.length;
	     String from = (message[c-1].getFrom()[0]).toString();
	     System.out.println("�������ǣ�" + from);
	     String subject1 = MimeUtility.decodeText((message[0]).getSubject());
	     System.out.println("�ʼ����⣺"+subject1);
	     String content = message[c-1].getContent().toString();
	     folder.close(false);
	     store.close();
	     
		return content;
	}

}
